# Text Poster

A Pen created on CodePen.

Original URL: [https://codepen.io/ghaste/pen/eYPGLBZ](https://codepen.io/ghaste/pen/eYPGLBZ).

